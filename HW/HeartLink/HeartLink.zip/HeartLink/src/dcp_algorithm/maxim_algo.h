#ifndef MAXIM_ALGO_H
#define MAXIM_ALGO_H

#include <stdint.h>
#include <stdbool.h>

// 算法需要的缓冲区大小（和你的 BATCH_SIZE 保持一致或更大）
#define ALGO_BUFFER_SIZE 400

/**
 * @brief Maxim 官方算法接口
 * * @param pun_ir_buffer  [输入] 红外光数据数组
 * @param n_ir_buffer_length [输入] 数据长度 (通常 100~400)
 * @param pun_red_buffer [输入] 红光数据数组
 * @param pn_spo2        [输出] 计算出的 SpO2 值
 * @param pch_spo2_valid [输出] SpO2 是否有效 (1=有效, 0=无效)
 * @param pn_heart_rate  [输出] 计算出的心率值
 * @param pch_hr_valid   [输出] 心率是否有效 (1=有效, 0=无效)
 */
void maxim_heart_rate_and_oxygen_saturation(uint32_t *pun_ir_buffer, int32_t n_ir_buffer_length,
                                            uint32_t *pun_red_buffer, int32_t *pn_spo2,
                                            int8_t *pch_spo2_valid, int32_t *pn_heart_rate,
                                            int8_t *pch_hr_valid);

#endif