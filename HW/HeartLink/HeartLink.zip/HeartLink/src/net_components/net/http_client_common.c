#include "esp_rom_sys.h"
#include "http_client_common.h"
#include "esp_http_client.h"
#include "esp_log.h"
#include <string.h>
#include <time.h>
#include <stdio.h>

// Provided by tls_bundle.c
extern const char root_ca_pem[];
#define API_KEY "HOLY_MOLY_123"

esp_err_t httpPostJson(const char *url, const char *json, int *status, int timeout_ms, int retry_max)
{
    esp_err_t ret = ESP_FAIL; 
    int sc = -1;

    for (int i = 0; i < retry_max; ++i) {
        // 1. 配置客户端
        esp_http_client_config_t cfg = {
            .url = url,
            .method = HTTP_METHOD_POST,
            .cert_pem = root_ca_pem,
            .timeout_ms = timeout_ms,
            .buffer_size = 4096,
        };

        esp_http_client_handle_t h = esp_http_client_init(&cfg);
        if (!h) {
            // 初始化失败
            if (i == retry_max - 1) break;
            vTaskDelay(pdMS_TO_TICKS(300 * (i+1)));
            continue;
        }

        // 2. 核心修正: 在 PERFORM 之前设置所有的 Header 和 POST 数据
        esp_http_client_set_header(h, "Content-Type", "application/json");
        esp_http_client_set_header(h, "x-api-key", API_KEY); // API_KEY 来自 http_client_common.c
        
        time_t now;
        time(&now);
        char ts_str[20];
        snprintf(ts_str, sizeof(ts_str), "%ld", (long)now);
        esp_http_client_set_header(h, "timestamp", ts_str);

        // 设置 POST 请求体
        esp_http_client_set_post_field(h, json, strlen(json)); 

        // 3. 执行请求
        ret = esp_http_client_perform(h);
        
        // 4. 处理结果
        if (ret == ESP_OK) {
            // sc = esp_http_client_get_status_code(h);
            // esp_rom_printf("[HTTP] POST Status = %d, content_length = %d\n",
            //                sc,
            //                (int)esp_http_client_get_content_length(h));
            sc = esp_http_client_get_status_code(h);
            esp_rom_printf("[HTTP] POST Status = %d, content_length = %d\n",
                           sc,
                           (int)esp_http_client_get_content_length(h));
            // 成功条件：HTTP 状态码在 2xx 范围内
            if (sc >= 200 && sc < 300) {
                esp_http_client_cleanup(h);
                if (status) *status = sc;
                return ESP_OK; // 上传成功，立即返回
            } else {
                // 服务器返回错误状态码（如 400, 401, 500）
                esp_rom_printf("DEBUG: Server responded with error status: %d\n", sc);
            }
        } else {
            // 传输错误 (TLS/TCP/DNS 错误)
            esp_rom_printf("DEBUG: HTTP Failed! Error: 0x%x (%s)\n", ret, esp_err_to_name(ret));
        }

        // 5. 清理客户端并等待重试
        esp_http_client_cleanup(h);
        if (i < retry_max - 1) {
            vTaskDelay(pdMS_TO_TICKS(300 * (i+1)));
        }
    }

    // 返回最终结果
    if (status) *status = sc;
    return ret; 
}

esp_err_t httpGetJson(const char *url, char *response_buf, int buf_len, int *status_code, int timeout_ms)
{
    esp_http_client_config_t cfg = {
        .url = url,
        .method = HTTP_METHOD_GET,
        .cert_pem = root_ca_pem,
        .timeout_ms = timeout_ms,
        .buffer_size = 4096,
        .event_handler = NULL,
    };

    esp_http_client_handle_t h = esp_http_client_init(&cfg);
    if (!h) return ESP_FAIL;

    // 1. 设置 Header
    esp_http_client_set_header(h, "Content-Type", "application/json");
    esp_http_client_set_header(h, "x-api-key", API_KEY);
    
    // 2. 执行请求
    esp_err_t ret = esp_http_client_perform(h);
    
    // 3. 获取 Content Length (用于调试)
    int contentLength = esp_http_client_get_content_length(h);
    
    // 4. 结果处理
    if (ret == ESP_OK) {
        if (status_code) *status_code = esp_http_client_get_status_code(h);
        
        int total_read = 0;
        int bytes_to_read = buf_len - 1; 

        // 打印调试信息，确认 Content Length
        esp_rom_printf("DEBUG: HTTP Received. Status: %d, Content-Length: %d\n", 
                       *status_code, contentLength);
        
        // 使用循环读取
        while (total_read < bytes_to_read) {
            // 使用 esp_http_client_read
            int len = esp_http_client_read(h, response_buf + total_read, bytes_to_read - total_read);
            
            if (len <= 0) {
                break; 
            }
            total_read += len;
            
            // 如果读取到的数据量等于 Content-Length，可以提前退出循环（可选优化）
            if (contentLength > 0 && total_read >= contentLength) {
                break;
            }
        }

        // 5. 打印最终结果
        response_buf[total_read] = 0; 
        esp_rom_printf("DEBUG: Actual bytes read (total_read): %d\n", total_read);
        
        if (total_read > 0) {
             esp_rom_printf("DEBUG: Final Response: %s\n", response_buf);
        } else {
             // 只有 total_read=0 时才打印 Content-Length=61 导致的错误
             esp_rom_printf("DEBUG: Read failed to get body data.\n");
        }
    } else {
        esp_rom_printf("DEBUG: HTTP Failed! Error: 0x%x (%s)\n", ret, esp_err_to_name(ret));
    }
    
    esp_http_client_cleanup(h);
    return ret;
}