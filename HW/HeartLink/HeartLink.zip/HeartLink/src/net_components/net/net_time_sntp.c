#include "esp_rom_sys.h"
#include "net_time_sntp.h"
#include "esp_sntp.h"
#include "esp_log.h"
#include <time.h>
#include <stdlib.h>

static const char *TAG = "SNTP";

bool sntpSyncOnce(const char *server, uint32_t timeoutMs)
{
    // 防止重复初始化
    sntp_stop();

    esp_rom_printf("[SNTP] Initializing SNTP using server: %s\n", server);
    
    sntp_setoperatingmode(SNTP_OPMODE_POLL);
    sntp_setservername(0, (char*)server);
    sntp_init();

    uint32_t waited = 0;
    bool syncSuccess = false; // [新增] 用于记录是否成功过
    
    while (waited < timeoutMs) {
        sntp_sync_status_t status = sntp_get_sync_status();
        
        // [关键修复] 只要捕捉到一次成功，立刻标记并退出！
        if (status == SNTP_SYNC_STATUS_COMPLETED) {
            esp_rom_printf("[SNTP] Status: 1 (Success!) -> Locking success state.\n");
            syncSuccess = true; // 锁定成功状态
            break;
        }

        vTaskDelay(pdMS_TO_TICKS(1000));
        waited += 1000;
        
        esp_rom_printf("[SNTP] Waiting... (%lu/%lu ms) Status: %d\n", 
                       (unsigned long)waited, (unsigned long)timeoutMs, status);
    }
    
    // [关键修复] 使用 syncSuccess 变量判断，而不是再次调用 sntp_get_sync_status()
    // 这样即使状态后来变回了 0，我们也算作成功。
    if (syncSuccess) {
        esp_rom_printf("[SNTP] Time synced successfully!\n");
        
        // 打印时间确认
        setenv("TZ", "EST5EDT,M3.2.0,M11.1.0", 1); 
        tzset(); 
        
        time_t now;
        struct tm timeinfo;
        time(&now);
        localtime_r(&now, &timeinfo);
        char strftime_buf[128];
        strftime(strftime_buf, sizeof(strftime_buf), "%Y-%m-%d %H:%M:%S", &timeinfo);

        esp_rom_printf("[SNTP] Current time: %s\n", strftime_buf);
        
    } else {
        esp_rom_printf("[SNTP] Timeout - System time may be wrong\n");
    }
    
    return syncSuccess;
}