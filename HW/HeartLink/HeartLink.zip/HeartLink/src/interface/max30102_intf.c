#include "max30102_intf.h"
#include "max30102_driver/max30102_driver.h"
#include "max30102_hal/hal_interrupt.h"
#include "esp_log.h"
#include "freertos/task.h"

static const char *TAG = "MAX_INTF";

// Handle for the data queue to send samples to the upload task
static QueueHandle_t dataQueueHandle = NULL;

// Handle for the sensor task
static TaskHandle_t sensorTaskHandle = NULL;

// Flag to control the task loop
static volatile bool isRunning = false;

/**
 * @brief Task to continuously read sensor data triggered by interrupts.
 */
static void sensorTask(void *arg) {
    // Start the sensor session with an infinite duration (or very long)
    max30102StartSession(0xFFFFFFFF); 

    max30102Sample currentSample;

    ESP_LOGI(TAG, "Sensor task started (Polling Mode active)");

    while (isRunning) {
        // [关键修改] 不再等待硬件中断 (interruptWaitEvent)
        // 而是主动延时 10ms (对应 100Hz 采样率)
        vTaskDelay(pdMS_TO_TICKS(10)); 

        // 直接尝试读取数据
        esp_err_t ret = max30102ReadSample(&currentSample);
        
        if (ret == ESP_OK) {
            // 读取成功，发送到队列
            if (dataQueueHandle != NULL) {
                if (xQueueSend(dataQueueHandle, &currentSample, 0) != pdTRUE) {
                    // 队列满了丢弃旧数据，防止阻塞
                    ESP_LOGW(TAG, "Queue full. Sample R:%u, IR:%u", 
                             (unsigned int)currentSample.red, (unsigned int)currentSample.ir);
                } else {
                    // [新增打印] 成功发送第一个样本后立即打印
                    ESP_LOGD(TAG, "Sample sent. R:%u, IR:%u", 
                             (unsigned int)currentSample.red, (unsigned int)currentSample.ir);
                }
            }
        }
        else if (ret == ESP_ERR_NOT_FOUND) {
            // 没有新样本，忽略，继续循环
        }
        else {
            // [新增打印] 读取失败，可能是 I2C 错误！
            ESP_LOGE(TAG, "Sensor Read FAILED with error: 0x%x (%s)", ret, esp_err_to_name(ret));
            // 失败后不应该持续占用 CPU，增加一点延时
            vTaskDelay(pdMS_TO_TICKS(50));
        }
    }
    // Stop the sensor hardware session
    max30102StopSession();
    
    ESP_LOGI(TAG, "Sensor task stopped");
    
    // Delete self
    vTaskDelete(NULL);
    sensorTaskHandle = NULL;
}

esp_err_t max30102IntfInit(QueueHandle_t queue) {
    if (queue == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    dataQueueHandle = queue;

    // Initialize the MAX30102 Driver
    return max30102Init();
}

esp_err_t max30102IntfStart(void) {
    if (sensorTaskHandle != NULL) {
        ESP_LOGW(TAG, "Task already running");
        return ESP_FAIL;
    }

    isRunning = true;
    // Create the task with relatively high priority to handle interrupts quickly
    BaseType_t ret = xTaskCreate(sensorTask, "sensorTask", 4096, NULL, 5, &sensorTaskHandle);
    
    return (ret == pdPASS) ? ESP_OK : ESP_FAIL;
}

void max30102IntfStop(void) {
    isRunning = false;
    // The task will exit its loop and delete itself
}